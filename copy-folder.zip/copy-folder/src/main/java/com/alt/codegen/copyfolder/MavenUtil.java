package com.alt.codegen.copyfolder;

import java.io.File;
import java.io.IOException;
import java.util.Collections;

import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.MavenInvocationException;

public class MavenUtil {

	/*public static void main(String args[]) throws IOException {
		executeMavenCommand("D:\\artifact-repo\\myfirstmuleproject\"");
	}*/

	/**
	 * This method is used to run the maven command.
	 * 
	 * @param path
	 */
	static public void executeMavenCommand(String path) {
		InvocationRequest request = new DefaultInvocationRequest();
		request.setPomFile(new File(path));
		request.setGoals(Collections.singletonList("clean install"));

		DefaultInvoker invoker = new DefaultInvoker();
		try {
			invoker.execute(request);
		} catch (MavenInvocationException e) {
			e.printStackTrace();
		}
	}
}