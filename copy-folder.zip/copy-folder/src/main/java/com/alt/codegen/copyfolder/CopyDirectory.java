package com.alt.codegen.copyfolder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class CopyDirectory {

	static final String REPO_SOURCE_URL = "C:\\Users\\jupadhyay\\Desktop\\Latest-Repo\\";
	static final String REPO_DESTIANTION_URL = "C:\\Users\\jupadhyay\\Desktop\\Latest-Repo\\";
	
	/*String rest_protocol = "HTTP";
	String rest_host = "localhost";
	String rest_port = "7070";
	String rest_basepath = "rest";

	String mule_service_protocol = "HTTP";
	String mule_service_host = "localhost";
	String mule_service_port = "8086";
	String mule_service_basepath = "rest";*/
	
	static String inputAsset = "workflow";
	static String outputAsset = "connector-1";
	static String resourcePath="\\src\\main\\resources\\";
	static String config_file="config.properties";


	public static void main(String[] args) throws IOException {
		
		File srcFolder = new File(REPO_SOURCE_URL + inputAsset);
		File destFolder = new File(REPO_DESTIANTION_URL + outputAsset);

		// make sure source exists
		if (!srcFolder.exists()) {

			System.out.println("Directory does not exist.");
			// just exit
			System.exit(0);

		} else {

			try {
				CopyDirectoryUtils.copyFolder(srcFolder, destFolder);
			} catch (IOException e) {
				e.printStackTrace();
				// error, just exit
				System.exit(0);
			}
		}

		System.out.println("Foler is copied ");
		
		Properties prop = new Properties();
		OutputStream output = null;

		try {

			output = new FileOutputStream(REPO_DESTIANTION_URL + outputAsset+resourcePath+config_file);

			// set the properties value
			prop.setProperty("mule.service.protocol", "HTTP");
			prop.setProperty("mule.service.host", "localhost");
			prop.setProperty("mule.service.port", "8888");
			prop.setProperty("mule.service.basepath", "workflow");
			
			prop.setProperty("rest.service.protocol", "HTTP");
			prop.setProperty("rest.service.host", "localhost");
			prop.setProperty("rest.service.port", "7070");
			prop.setProperty("rest.service.basepath", "rest");

			prop.setProperty("rest.service.demoapi.product", "products");
			prop.setProperty("rest.service.demoapi.profile", "profile");
								
			// save properties to project root folder
			prop.store(output, null);

			System.out.println("Done with Copy ");
			
			MavenUtil.executeMavenCommand(REPO_DESTIANTION_URL+outputAsset+"\\");
			
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
}
